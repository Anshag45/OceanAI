"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { RefinementHistory } from "./refinement-history"
import { getToken } from "@/lib/client-auth"

interface Refinement {
  id: string
  prompt: string
  refined_content: string
  likes: number
  dislikes: number
  created_at: string
}

interface SectionEditorProps {
  sectionId: string
  sectionTitle: string
  projectTopic: string
  initialContent?: string
  onContentGenerated: (content: string) => void
}

export function SectionEditor({
  sectionId,
  sectionTitle,
  projectTopic,
  initialContent = "",
  onContentGenerated,
}: SectionEditorProps) {
  const [content, setContent] = useState(initialContent)
  const [refinementPrompt, setRefinementPrompt] = useState("")
  const [generating, setGenerating] = useState(false)
  const [refining, setRefining] = useState(false)
  const [showHistory, setShowHistory] = useState(false)

  const handleGenerateContent = async () => {
    setGenerating(true)
    try {
      const token = getToken()
      const res = await fetch("/api/generate/section", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          sectionId,
          sectionTitle,
          projectTopic,
        }),
      })

      if (res.ok) {
        const data = await res.json()
        setContent(data.content)
        onContentGenerated(data.content)
      }
    } catch (error) {
      console.error("Error generating content:", error)
    } finally {
      setGenerating(false)
    }
  }

  const handleRefineContent = async () => {
    if (!refinementPrompt.trim()) return

    setRefining(true)
    try {
      const token = getToken()
      const res = await fetch("/api/generate/refine", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          sectionId,
          currentContent: content,
          refinementPrompt,
        }),
      })

      if (res.ok) {
        const data = await res.json()
        setContent(data.content)
        setRefinementPrompt("")
        onContentGenerated(data.content)
      }
    } catch (error) {
      console.error("Error refining content:", error)
    } finally {
      setRefining(false)
    }
  }

  const handleUseRefinement = (refinement: Refinement) => {
    setContent(refinement.refined_content)
    onContentGenerated(refinement.refined_content)
    setShowHistory(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        <Button onClick={handleGenerateContent} disabled={generating} variant="default">
          {generating ? "Generating..." : "Generate Content"}
        </Button>
        <Button onClick={() => setShowHistory(!showHistory)} variant="outline">
          {showHistory ? "Hide" : "Show"} History
        </Button>
      </div>

      {content && (
        <Card className="p-6 bg-card border-border">
          <div className="mb-4 pb-4 border-b border-border">
            <p className="text-sm text-muted-foreground mb-2">Current Content</p>
            <p className="text-foreground whitespace-pre-wrap">{content}</p>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium">Refine Content</label>
            <Input
              value={refinementPrompt}
              onChange={(e) => setRefinementPrompt(e.target.value)}
              placeholder="e.g., Make this more formal, add more details, shorten this..."
            />
            <Button
              onClick={handleRefineContent}
              disabled={refining || !refinementPrompt.trim()}
              variant="outline"
              className="w-full bg-transparent"
            >
              {refining ? "Refining..." : "Refine"}
            </Button>
          </div>
        </Card>
      )}

      {showHistory && (
        <div>
          <h3 className="font-semibold mb-3">Refinement History</h3>
          <RefinementHistory sectionId={sectionId} onSelectRefinement={handleUseRefinement} />
        </div>
      )}
    </div>
  )
}
