"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { getToken } from "@/lib/client-auth"

interface CreateProjectModalProps {
  onClose: () => void
  onProjectCreated: () => void
}

export function CreateProjectModal({ onClose, onProjectCreated }: CreateProjectModalProps) {
  const [step, setStep] = useState<"type" | "details">("type")
  const [documentType, setDocumentType] = useState<"docx" | "pptx" | null>(null)
  const [topic, setTopic] = useState("")
  const [loading, setLoading] = useState(false)

  const handleTypeSelect = (type: "docx" | "pptx") => {
    setDocumentType(type)
    setStep("details")
  }

  const handleCreate = async () => {
    if (!documentType || !topic.trim()) return

    setLoading(true)
    try {
      const token = getToken()
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          documentType,
          topic,
        }),
      })

      if (res.ok) {
        onProjectCreated()
        onClose()
      }
    } catch (error) {
      console.error("Error creating project:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <div className="p-8">
          {step === "type" ? (
            <>
              <h2 className="text-2xl font-bold mb-6">Choose Document Type</h2>
              <div className="space-y-3">
                <button
                  onClick={() => handleTypeSelect("docx")}
                  className="w-full p-4 border border-border rounded-lg hover:bg-secondary transition text-left"
                >
                  <div className="text-2xl mb-2">📄</div>
                  <div className="font-semibold">Word Document (.docx)</div>
                  <p className="text-sm text-muted-foreground">Perfect for reports, proposals, and guides</p>
                </button>
                <button
                  onClick={() => handleTypeSelect("pptx")}
                  className="w-full p-4 border border-border rounded-lg hover:bg-secondary transition text-left"
                >
                  <div className="text-2xl mb-2">🎬</div>
                  <div className="font-semibold">PowerPoint Presentation (.pptx)</div>
                  <p className="text-sm text-muted-foreground">Great for slideshows and presentations</p>
                </button>
              </div>
              <Button variant="outline" className="w-full mt-6 bg-transparent" onClick={onClose}>
                Cancel
              </Button>
            </>
          ) : (
            <>
              <h2 className="text-2xl font-bold mb-2">Create New Project</h2>
              <p className="text-sm text-muted-foreground mb-6">
                Document Type: <span className="font-semibold text-foreground">{documentType?.toUpperCase()}</span>
              </p>

              <div>
                <label className="block text-sm font-medium mb-2">Project Topic</label>
                <Input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g., Annual Report 2024"
                  className="mb-6"
                />
              </div>

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent" onClick={() => setStep("type")}>
                  Back
                </Button>
                <Button className="flex-1" onClick={handleCreate} disabled={!topic.trim() || loading}>
                  {loading ? "Creating..." : "Create Project"}
                </Button>
              </div>
            </>
          )}
        </div>
      </Card>
    </div>
  )
}
