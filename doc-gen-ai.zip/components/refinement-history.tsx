"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { getToken } from "@/lib/client-auth"

interface Refinement {
  id: string
  prompt: string
  refined_content: string
  likes: number
  dislikes: number
  created_at: string
}

interface Comment {
  id: string
  content: string
  created_at: string
}

interface RefinementHistoryProps {
  sectionId: string
  onSelectRefinement: (refinement: Refinement) => void
}

export function RefinementHistory({ sectionId, onSelectRefinement }: RefinementHistoryProps) {
  const [refinements, setRefinements] = useState<Refinement[]>([])
  const [expandedRefinement, setExpandedRefinement] = useState<string | null>(null)
  const [comments, setComments] = useState<Record<string, Comment[]>>({})
  const [newComments, setNewComments] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchRefinements()
  }, [sectionId])

  const fetchRefinements = async () => {
    try {
      const token = getToken()
      const res = await fetch(`/api/sections/${sectionId}/refinements`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      if (res.ok) {
        const data = await res.json()
        setRefinements(data)
      }
    } catch (error) {
      console.error("Error fetching refinements:", error)
    }
  }

  const fetchComments = async (refinementId: string) => {
    try {
      const token = getToken()
      const res = await fetch(`/api/refinements/${refinementId}/comments`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      if (res.ok) {
        const data = await res.json()
        setComments((prev) => ({ ...prev, [refinementId]: data }))
      }
    } catch (error) {
      console.error("Error fetching comments:", error)
    }
  }

  const handleAddComment = async (refinementId: string) => {
    const comment = newComments[refinementId]?.trim()
    if (!comment) return

    try {
      const token = getToken()
      const res = await fetch(`/api/refinements/${refinementId}/comments`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: comment }),
      })

      if (res.ok) {
        setNewComments((prev) => ({ ...prev, [refinementId]: "" }))
        await fetchComments(refinementId)
      }
    } catch (error) {
      console.error("Error adding comment:", error)
    }
  }

  const handleLike = async (refinementId: string, currentLikes: number) => {
    try {
      const token = getToken()
      await fetch(`/api/refinements/${refinementId}/like`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ liked: currentLikes === 0 }),
      })

      setRefinements(refinements.map((r) => (r.id === refinementId ? { ...r, likes: currentLikes === 0 ? 1 : 0 } : r)))
    } catch (error) {
      console.error("Error updating like:", error)
    }
  }

  const handleDislike = async (refinementId: string, currentDislikes: number) => {
    try {
      const token = getToken()
      await fetch(`/api/refinements/${refinementId}/dislike`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ disliked: currentDislikes === 0 }),
      })

      setRefinements(
        refinements.map((r) => (r.id === refinementId ? { ...r, dislikes: currentDislikes === 0 ? 1 : 0 } : r)),
      )
    } catch (error) {
      console.error("Error updating dislike:", error)
    }
  }

  if (refinements.length === 0) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground">No refinement history yet</p>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {refinements.map((refinement) => (
        <Card key={refinement.id} className="overflow-hidden">
          <button
            onClick={() => {
              setExpandedRefinement(expandedRefinement === refinement.id ? null : refinement.id)
              if (expandedRefinement !== refinement.id) {
                fetchComments(refinement.id)
              }
            }}
            className="w-full text-left p-4 hover:bg-secondary transition"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground mb-1">{refinement.prompt}</p>
                <p className="text-xs text-muted-foreground">{new Date(refinement.created_at).toLocaleString()}</p>
              </div>
              <span className="text-xl">{expandedRefinement === refinement.id ? "▼" : "▶"}</span>
            </div>
          </button>

          {expandedRefinement === refinement.id && (
            <div className="border-t border-border bg-card p-4 space-y-4">
              <div>
                <p className="text-sm text-foreground whitespace-pre-wrap">{refinement.refined_content}</p>
              </div>

              <div className="flex gap-2">
                <Button
                  variant={refinement.likes ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleLike(refinement.id, refinement.likes)}
                >
                  👍 Like
                </Button>
                <Button
                  variant={refinement.dislikes ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleDislike(refinement.id, refinement.dislikes)}
                >
                  👎 Dislike
                </Button>
                <Button variant="outline" size="sm" onClick={() => onSelectRefinement(refinement)} className="ml-auto">
                  Use This
                </Button>
              </div>

              <div className="border-t border-border pt-4 space-y-3">
                <p className="text-sm font-medium">Comments</p>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {comments[refinement.id]?.map((comment) => (
                    <div key={comment.id} className="bg-muted p-2 rounded text-sm">
                      <p className="text-foreground">{comment.content}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(comment.created_at).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Input
                    value={newComments[refinement.id] || ""}
                    onChange={(e) =>
                      setNewComments((prev) => ({
                        ...prev,
                        [refinement.id]: e.target.value,
                      }))
                    }
                    placeholder="Add a comment..."
                    size={undefined}
                  />
                  <Button size="sm" onClick={() => handleAddComment(refinement.id)}>
                    Add
                  </Button>
                </div>
              </div>
            </div>
          )}
        </Card>
      ))}
    </div>
  )
}
