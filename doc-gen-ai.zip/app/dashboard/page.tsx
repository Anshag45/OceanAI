"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ProjectCard } from "@/components/project-card"
import { CreateProjectModal } from "@/components/create-project-modal"
import { ProtectedRoute } from "@/components/protected-route"
import { getToken, removeToken } from "@/lib/client-auth"

interface Project {
  id: string
  topic: string
  document_type: "docx" | "pptx"
  created_at: string
}

export default function DashboardPage() {
  const router = useRouter()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    fetchProjects()
  }, [])

  const fetchProjects = async () => {
    try {
      const token = getToken()
      const res = await fetch("/api/projects", {
        headers: { Authorization: `Bearer ${token}` },
      })

      if (res.ok) {
        const data = await res.json()
        setProjects(data)
      } else if (res.status === 401) {
        router.push("/login")
      }
    } catch (error) {
      console.error("Error fetching projects:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    removeToken()
    router.push("/")
  }

  return (
    <ProtectedRoute>
      <main className="min-h-screen bg-gradient-to-br from-background via-secondary to-background">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold">DocGen AI</h1>
              <p className="text-muted-foreground">Your AI-powered document projects</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Sign Out
            </Button>
          </div>

          {/* Create New Project Button */}
          <div className="mb-8">
            <Button
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              size="lg"
              onClick={() => setShowModal(true)}
            >
              + Create New Project
            </Button>
          </div>

          {/* Projects Grid */}
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading projects...</p>
              </div>
            </div>
          ) : projects.length === 0 ? (
            <Card className="p-12 text-center">
              <div className="text-5xl mb-4">📚</div>
              <h2 className="text-2xl font-semibold mb-2">No projects yet</h2>
              <p className="text-muted-foreground mb-6">
                Create your first document project to get started with AI-powered generation
              </p>
              <Button onClick={() => setShowModal(true)}>Create Your First Project</Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  id={project.id}
                  topic={project.topic}
                  documentType={project.document_type}
                  createdAt={project.created_at}
                />
              ))}
            </div>
          )}
        </div>

        {showModal && <CreateProjectModal onClose={() => setShowModal(false)} onProjectCreated={fetchProjects} />}
      </main>
    </ProtectedRoute>
  )
}
