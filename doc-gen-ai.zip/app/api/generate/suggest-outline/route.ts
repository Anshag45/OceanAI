import { aiService } from "@/lib/services/ai-service"
import { verifyToken } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return Response.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.slice(7)
    const payload = await verifyToken(token)
    if (!payload) {
      return Response.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { projectId, documentType } = await request.json()

    const prompt =
      documentType === "docx"
        ? `Generate 5 section titles for a professional business document. Format as a JSON array of strings only, no explanations.`
        : `Generate 8 slide titles for a professional business presentation. Format as a JSON array of strings only, no explanations.`

    const text = await aiService.generateContent(
      {
        prompt,
        maxTokens: 500,
      },
      payload.userId,
    )

    const outline = JSON.parse(text)
    return Response.json({ outline })
  } catch (error) {
    console.error("[v0] Error generating outline:", error)
    const message = error instanceof Error ? error.message : "Error generating outline"
    return Response.json({ message }, { status: 500 })
  }
}
