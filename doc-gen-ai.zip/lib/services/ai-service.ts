import { generateText } from "ai"

// Rate limiting store (in-memory for now; use Redis in production)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

const RATE_LIMIT_WINDOW = 60000 // 1 minute
const RATE_LIMIT_MAX = 10 // max requests per window

interface AIServiceConfig {
  useMock?: boolean
  model?: string
  maxRetries?: number
}

interface ContentGenerationRequest {
  prompt: string
  maxTokens?: number
  temperature?: number
}

export class AIService {
  private useMock: boolean
  private model: string
  private maxRetries: number

  constructor(config: AIServiceConfig = {}) {
    this.useMock = config.useMock ?? (process.env.NODE_ENV === "test" || !process.env.OPENAI_API_KEY)
    this.model = config.model ?? "openai/gpt-4o-mini"
    this.maxRetries = config.maxRetries ?? 3
  }

  private checkRateLimit(userId: string): boolean {
    const now = Date.now()
    const userLimit = rateLimitStore.get(userId)

    if (!userLimit || now > userLimit.resetTime) {
      rateLimitStore.set(userId, { count: 1, resetTime: now + RATE_LIMIT_WINDOW })
      return true
    }

    if (userLimit.count >= RATE_LIMIT_MAX) {
      return false
    }

    userLimit.count++
    return true
  }

  async generateContent(request: ContentGenerationRequest, userId?: string): Promise<string> {
    try {
      // Check rate limit if userId provided
      if (userId && !this.checkRateLimit(userId)) {
        throw new Error("Rate limit exceeded. Please try again later.")
      }

      if (this.useMock) {
        return this.generateMockContent(request.prompt)
      }

      return await this.callAI(request)
    } catch (error) {
      console.error("[v0] AI Service error:", error)
      throw this.handleError(error)
    }
  }

  private async callAI(request: ContentGenerationRequest): Promise<string> {
    let lastError: Error | null = null

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const { text } = await generateText({
          model: this.model,
          prompt: request.prompt,
          maxOutputTokens: request.maxTokens ?? 2000,
          temperature: request.temperature ?? 0.7,
        })
        return text
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error))
        console.error(`[v0] AI attempt ${attempt}/${this.maxRetries} failed:`, lastError)

        // Don't retry on auth errors
        if (lastError.message.includes("Unauthorized") || lastError.message.includes("API key")) {
          throw new Error("Authentication failed. Check your API configuration.")
        }

        // Exponential backoff
        if (attempt < this.maxRetries) {
          await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000))
        }
      }
    }

    throw lastError || new Error("Failed to generate content after multiple attempts")
  }

  private generateMockContent(prompt: string): string {
    const mockResponses: Record<string, string> = {
      outline: JSON.stringify([
        "Introduction & Executive Summary",
        "Market Analysis",
        "Product Overview",
        "Implementation Strategy",
        "Timeline & Milestones",
      ]),
      section:
        "This is a comprehensive section generated in mock mode. It covers all relevant aspects of the topic with professional detail and structure. The content is placeholder but demonstrates proper formatting and organization.",
      refinement:
        "The refined content maintains the original structure while improving clarity and impact. It has been enhanced based on the feedback provided and now follows best practices for professional documentation.",
    }

    if (prompt.includes("section title")) {
      return mockResponses.section
    }
    if (prompt.includes("JSON array")) {
      return mockResponses.outline
    }
    if (prompt.includes("refine")) {
      return mockResponses.refinement
    }

    return `Mock response for: ${prompt.substring(0, 100)}...`
  }

  private handleError(error: unknown): Error {
    if (error instanceof Error) {
      if (error.message.includes("rate_limit_exceeded")) {
        return new Error("API rate limit exceeded. Please try again in a moment.")
      }
      if (error.message.includes("model_not_found")) {
        return new Error("AI model is not available. Please contact support.")
      }
      if (error.message.includes("context_length_exceeded")) {
        return new Error("The content is too long to process. Please try a shorter input.")
      }
      return error
    }
    return new Error("An unexpected error occurred with the AI service")
  }

  // Enable/disable mock mode dynamically
  setMockMode(useMock: boolean) {
    this.useMock = useMock
  }

  // Get current rate limit status
  getRateLimitStatus(userId: string) {
    const userLimit = rateLimitStore.get(userId)
    const now = Date.now()

    if (!userLimit || now > userLimit.resetTime) {
      return { remaining: RATE_LIMIT_MAX, resetIn: 0 }
    }

    return {
      remaining: Math.max(0, RATE_LIMIT_MAX - userLimit.count),
      resetIn: userLimit.resetTime - now,
    }
  }
}

// Singleton instance
export const aiService = new AIService()
