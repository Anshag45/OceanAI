"use client"

import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface ProjectCardProps {
  id: string
  topic: string
  documentType: "docx" | "pptx"
  createdAt: string
}

export function ProjectCard({ id, topic, documentType, createdAt }: ProjectCardProps) {
  const router = useRouter()
  const date = new Date(createdAt).toLocaleDateString()
  const icon = documentType === "docx" ? "📄" : "🎬"

  return (
    <Card className="p-6 cursor-pointer hover:shadow-lg transition-shadow h-full">
      <div className="flex items-start justify-between mb-4">
        <span className="text-3xl">{icon}</span>
        <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded">
          {documentType.toUpperCase()}
        </span>
      </div>
      <h3 className="font-semibold text-lg mb-2 line-clamp-2">{topic}</h3>
      <p className="text-sm text-muted-foreground mb-4">{date}</p>
      <Button variant="outline" size="sm" className="w-full bg-transparent" onClick={() => router.push(`/setup/${id}`)}>
        Open Project
      </Button>
    </Card>
  )
}
