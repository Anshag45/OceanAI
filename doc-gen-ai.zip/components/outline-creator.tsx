"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { getToken } from "@/lib/client-auth"

interface OutlineCreatorProps {
  projectId: string
  documentType: "docx" | "pptx"
  onOutlineCreated: () => void
}

export function OutlineCreator({ projectId, documentType, onOutlineCreated }: OutlineCreatorProps) {
  const [sections, setSections] = useState<string[]>(["", ""])
  const [loading, setLoading] = useState(false)
  const [suggestLoading, setSuggestLoading] = useState(false)

  const addSection = () => {
    setSections([...sections, ""])
  }

  const removeSection = (index: number) => {
    setSections(sections.filter((_, i) => i !== index))
  }

  const updateSection = (index: number, value: string) => {
    const updated = [...sections]
    updated[index] = value
    setSections(updated)
  }

  const handleSuggestOutline = async () => {
    setSuggestLoading(true)
    try {
      const token = getToken()
      const res = await fetch("/api/generate/suggest-outline", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          projectId,
          documentType,
        }),
      })

      if (res.ok) {
        const data = await res.json()
        setSections(data.outline)
      }
    } catch (error) {
      console.error("Error suggesting outline:", error)
    } finally {
      setSuggestLoading(false)
    }
  }

  const handleCreateOutline = async () => {
    const filledSections = sections.filter((s) => s.trim())
    if (filledSections.length === 0) return

    setLoading(true)
    try {
      const token = getToken()
      const res = await fetch(`/api/projects/${projectId}/outline`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          sections: filledSections,
        }),
      })

      if (res.ok) {
        onOutlineCreated()
      }
    } catch (error) {
      console.error("Error creating outline:", error)
    } finally {
      setLoading(false)
    }
  }

  const sectionLabel = documentType === "docx" ? "Section" : "Slide"

  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <Button variant="outline" onClick={handleSuggestOutline} disabled={suggestLoading}>
          {suggestLoading ? "Generating..." : "✨ AI Suggest Outline"}
        </Button>
      </div>

      <div className="space-y-3">
        {sections.map((section, index) => (
          <div key={index} className="flex gap-3">
            <div className="flex-1">
              <label className="text-sm font-medium mb-1 block">
                {sectionLabel} {index + 1}
              </label>
              <Input
                value={section}
                onChange={(e) => updateSection(index, e.target.value)}
                placeholder={`Enter ${sectionLabel.toLowerCase()} title`}
              />
            </div>
            {sections.length > 1 && (
              <div className="flex items-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeSection(index)}
                  className="text-destructive hover:text-destructive"
                >
                  Remove
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" onClick={addSection} className="w-full bg-transparent">
        + Add Another {sectionLabel}
      </Button>

      <Card className="bg-secondary/50 p-4">
        <p className="text-sm text-muted-foreground">
          {sections.filter((s) => s.trim()).length} {sectionLabel.toLowerCase()}(s) ready to generate
        </p>
      </Card>

      <Button
        className="w-full"
        onClick={handleCreateOutline}
        disabled={loading || sections.filter((s) => s.trim()).length === 0}
      >
        {loading ? "Creating Outline..." : "Create Outline & Generate Content"}
      </Button>
    </div>
  )
}
