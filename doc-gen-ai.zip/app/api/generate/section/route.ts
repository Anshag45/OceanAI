import { aiService } from "@/lib/services/ai-service"
import { verifyToken } from "@/lib/auth"
import { updateSection } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return Response.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.slice(7)
    const payload = await verifyToken(token)
    if (!payload) {
      return Response.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { sectionId, sectionTitle, projectTopic } = await request.json()

    if (!sectionId || !sectionTitle || !projectTopic) {
      return Response.json({ message: "Missing required fields" }, { status: 400 })
    }

    const content = await aiService.generateContent(
      {
        prompt: `Write a comprehensive section for a business document about "${projectTopic}" with the title "${sectionTitle}". Keep it professional and between 150-300 words.`,
        maxTokens: 2000,
      },
      payload.userId,
    )

    await updateSection(sectionId, content)

    return Response.json({ content })
  } catch (error) {
    console.error("[v0] Error generating section:", error)
    const message = error instanceof Error ? error.message : "Error generating section"
    return Response.json({ message }, { status: 500 })
  }
}
