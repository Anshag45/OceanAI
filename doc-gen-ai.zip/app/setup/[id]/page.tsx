"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { OutlineCreator } from "@/components/outline-creator"
import { ProtectedRoute } from "@/components/protected-route"
import { getToken } from "@/lib/client-auth"

interface Project {
  id: string
  topic: string
  document_type: "docx" | "pptx"
}

export default function SetupPage() {
  const router = useRouter()
  const params = useParams()
  const projectId = params.id as string

  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProject = async () => {
      try {
        const token = getToken()
        const res = await fetch(`/api/projects/${projectId}`, {
          headers: { Authorization: `Bearer ${token}` },
        })

        if (res.ok) {
          const data = await res.json()
          setProject(data[0])
        } else {
          router.push("/dashboard")
        }
      } catch (error) {
        console.error("Error fetching project:", error)
        router.push("/dashboard")
      } finally {
        setLoading(false)
      }
    }

    fetchProject()
  }, [projectId, router])

  if (loading || !project) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading project...</p>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <main className="min-h-screen bg-gradient-to-br from-background via-secondary to-background">
        <div className="max-w-3xl mx-auto px-4 py-12">
          <div className="mb-8">
            <Button variant="ghost" onClick={() => router.back()}>
              ← Back
            </Button>
          </div>

          <Card className="p-8">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">{project.topic}</h1>
              <p className="text-muted-foreground">
                {project.document_type === "docx" ? "Document" : "Presentation"} • Set up your structure
              </p>
            </div>

            <OutlineCreator
              projectId={project.id}
              documentType={project.document_type}
              onOutlineCreated={() => router.push(`/editor/${project.id}`)}
            />
          </Card>
        </div>
      </main>
    </ProtectedRoute>
  )
}
